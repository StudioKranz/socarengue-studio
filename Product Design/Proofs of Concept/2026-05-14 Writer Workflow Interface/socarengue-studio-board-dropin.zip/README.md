# Socarengue Studio collaborator workflow board

Status: Review prototype, not final product direction.

This bundle adds a more useful Studio Mode proof of concept for collaborator review:

- a writer-focused workflow board
- real Socarengue seed tasks based on Issue 01, Glen, Mara, Ovi, Lucien, Underpass Chorus, Rain Signal, The Cassette Room, and archive candidates
- a Socarengue Copilot panel for surfacing next steps
- artifact upload labels for future public archive/lore readiness

## Files to copy into the repo

Copy these into `StudioKranz/socarengue-studio`:

```txt
src/lib/studio/workflow.ts
src/components/studio/studio-workflow-board.tsx
src/components/studio/studio-overview.tsx
```

That updates `/studio` without changing the public homepage.

## Optional direct-link behavior

If `https://socarengue.studio/` should go straight to Studio Mode during collaborator review, also copy:

```txt
optional-root-redirect/src/app/page.tsx -> src/app/page.tsx
```

That makes the domain root redirect to `/studio`. Do not use this optional file if you want the public Reader Mode landing page to remain at `/`.

## Local validation

From the repository root:

```bash
pnpm install
pnpm typecheck
pnpm build
pnpm dev
```

Then open:

```txt
http://localhost:3000/studio
```

If you used the optional redirect, also open:

```txt
http://localhost:3000/
```

## Deployment note

The repository README already assumes Vercel later. Once the repo is imported into Vercel and deployed, add `socarengue.studio` as the custom domain in Vercel and configure DNS at the current DNS host.

For a temporary review URL, leave the root page unchanged and share:

```txt
https://socarengue.studio/studio
```

For a direct collaborator proof-of-concept URL, use the optional redirect so:

```txt
https://socarengue.studio/
```

opens the Studio workflow board.
