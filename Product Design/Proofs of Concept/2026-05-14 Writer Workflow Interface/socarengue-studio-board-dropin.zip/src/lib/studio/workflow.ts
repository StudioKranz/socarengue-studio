export type StudioLaneId =
  | "gaps"
  | "needs-input"
  | "drafting"
  | "review"
  | "archive-candidate";

export type StudioPriority = "high" | "medium" | "low";

export interface StudioLane {
  id: StudioLaneId;
  title: string;
  description: string;
}

export interface StudioTask {
  id: string;
  laneId: StudioLaneId;
  title: string;
  type: string;
  storyArea: string;
  owner: string;
  collaborator?: string;
  priority: StudioPriority;
  dueLabel: string;
  statusLabel: string;
  blocker?: string;
  decisionState: "proposal" | "needs-comment" | "needs-approval" | "ready-to-work" | "not-final";
  summary: string;
  nextStep: string;
  aiAssist: string;
  linkedItems: string[];
  tags: string[];
}

export const studioLanes: StudioLane[] = [
  {
    id: "gaps",
    title: "Gaps / Intake",
    description: "Story bible holes, untriaged uploads, or questions that need shape.",
  },
  {
    id: "needs-input",
    title: "Needs Input",
    description: "Blocked until another collaborator, frame order, or approval note arrives.",
  },
  {
    id: "drafting",
    title: "Drafting",
    description: "Ready for a writer, artist, or archive editor to move now.",
  },
  {
    id: "review",
    title: "Review / Approve",
    description: "Needs a decision before becoming canon, production direction, or public copy.",
  },
  {
    id: "archive-candidate",
    title: "Archive Candidate",
    description: "Potential public-facing lore, artifact, or behind-the-scenes material.",
  },
];

export const studioTasks: StudioTask[] = [
  {
    id: "task-underpass-dialogue-frames",
    laneId: "needs-input",
    title: "Underpass Chorus dialogue is blocked by missing frame order",
    type: "Dialogue dependency",
    storyArea: "Issue 01 / Underpass Chorus",
    owner: "Glen",
    collaborator: "Storyboard / Art",
    priority: "high",
    dueLabel: "Before dialogue pass",
    statusLabel: "Blocked",
    blocker: "Needs rough order for frames 08-12 before final call-and-response dialogue can be written.",
    decisionState: "needs-comment",
    summary:
      "Glen can sketch the emotional rhythm, but the final line breaks depend on whether the poster wall, rail tap, and city response are one beat or three separate frames.",
    nextStep: "Request a rough frame sequence from storyboard and attach it to the scene workspace.",
    aiAssist:
      "Draft a short request to art: 'Can you confirm whether frames 08-12 play as one continuous reveal or separate beats? Glen needs timing before final dialogue.'",
    linkedItems: ["scene_underpass_chorus", "artifact_underpass_poster", "cue_underpass_chorus"],
    tags: ["dialogue", "storyboard", "blocked", "Glen"],
  },
  {
    id: "task-mara-voice-gap",
    laneId: "gaps",
    title: "Define Mara's voice rule before new scene dialogue",
    type: "Story bible gap",
    storyArea: "Character / Mara Vale",
    owner: "Glen",
    priority: "high",
    dueLabel: "This week",
    statusLabel: "Open gap",
    decisionState: "ready-to-work",
    summary:
      "Mara notices rhythm in broken infrastructure, but the bible needs a usable dialogue rule: what does she say plainly, what does she only notice, and what does she avoid naming?",
    nextStep: "Write three voice constraints and one sample exchange for Mara in Rain Signal.",
    aiAssist:
      "Generate a one-page voice card from existing Mara notes, then ask Glen to approve or rewrite the constraints.",
    linkedItems: ["character_mara", "scene_rain_signal", "lore_city_memory"],
    tags: ["voice", "character", "bible", "dialogue"],
  },
  {
    id: "task-lucien-ledger-lines",
    laneId: "drafting",
    title: "Draft Lucien ledger-room exchange",
    type: "Dialogue draft",
    storyArea: "Issue 01 / The Cassette Room",
    owner: "Glen",
    priority: "medium",
    dueLabel: "Next writing pass",
    statusLabel: "Ready",
    decisionState: "ready-to-work",
    summary:
      "The line 'Do not catalog the chorus alone' is strong, but the scene needs two versions: one restrained archive-keeper version and one more haunted version.",
    nextStep: "Draft two dialogue options and attach both to the Cassette Room scene for review.",
    aiAssist:
      "Prepare two tone variants and preserve the better unresolved ending for collaborator review.",
    linkedItems: ["scene_cassette_room", "artifact_ledger_page", "artifact_gold_cassette"],
    tags: ["dialogue", "Lucien", "cassette", "draft"],
  },
  {
    id: "task-ovi-resonance-limit",
    laneId: "gaps",
    title: "Clarify Ovi's resonance limit",
    type: "Lore rule",
    storyArea: "Character / Ovi Reyes",
    owner: "Story lead",
    collaborator: "Glen",
    priority: "medium",
    dueLabel: "Before Issue 02 planning",
    statusLabel: "Needs shape",
    decisionState: "proposal",
    summary:
      "Ovi can amplify hidden city patterns during live sets, but the system needs a clear limit so future story beats do not feel arbitrary.",
    nextStep: "Propose one power limit, one emotional cost, and one visual cue for review.",
    aiAssist:
      "Surface all Ovi notes and suggest three consistent limits that preserve mystery without overexplaining the mythology.",
    linkedItems: ["character_ovi", "lore_resonance", "artifact_ovi_issue_artwork"],
    tags: ["Ovi", "resonance", "canon", "limits"],
  },
  {
    id: "task-rain-signal-beat-change",
    laneId: "review",
    title: "Review beat change: should the streetlight answer before Ovi appears?",
    type: "Story beat proposal",
    storyArea: "Issue 01 / Rain Signal",
    owner: "Story lead",
    collaborator: "Glen",
    priority: "medium",
    dueLabel: "Review pass",
    statusLabel: "Proposed",
    decisionState: "needs-approval",
    summary:
      "A suggested beat would let the flickering streetlight answer the cassette before Mara sees Ovi. This may make the city feel more active, but could reveal the mythology too early.",
    nextStep: "Approve, reject, or mark as alternate beat before storyboard adjustment.",
    aiAssist:
      "Summarize the impact on pacing, mystery, and visual continuity, then draft a review note for the story lead.",
    linkedItems: ["scene_rain_signal", "artifact_broken_speaker", "lore_city_memory"],
    tags: ["beat", "approval", "storyboard", "pacing"],
  },
  {
    id: "task-ovi-public-copy",
    laneId: "review",
    title: "Polish Ovi Artwork public archive copy",
    type: "Archive copy review",
    storyArea: "Artifact / Ovi Artwork",
    owner: "Archive editor",
    collaborator: "Glen",
    priority: "low",
    dueLabel: "Before public archive refresh",
    statusLabel: "In review",
    decisionState: "needs-approval",
    summary:
      "The copy should feel like a discovered image, not promo language. Keep the mystery while making the artifact understandable to a new visitor.",
    nextStep: "Approve the public description or request a less explanatory version.",
    aiAssist:
      "Rewrite the description in two modes: 'archive card' and 'behind-the-scenes note.'",
    linkedItems: ["artifact_ovi_issue_artwork", "character_ovi", "scene_underpass_chorus"],
    tags: ["archive", "public-copy", "Ovi", "review"],
  },
  {
    id: "task-cassette-archive-labels",
    laneId: "archive-candidate",
    title: "Label Cassette With Gold Ink for potential public archive use",
    type: "Artifact intake",
    storyArea: "Artifact / Cassette With Gold Ink",
    owner: "Archive editor",
    priority: "high",
    dueLabel: "Before archive publish decision",
    statusLabel: "Candidate",
    decisionState: "not-final",
    summary:
      "This object is a strong public archive candidate, but it needs rights status, spoiler level, transcript confidence, and linked lore reviewed before it can move public.",
    nextStep: "Complete metadata labels and request final spoiler review.",
    aiAssist:
      "Suggest metadata: canon status, spoiler level, visibility, rights note, transcript confidence, and public-use recommendation.",
    linkedItems: ["artifact_gold_cassette", "lore_gold_ink", "track_gold_ink_chorus"],
    tags: ["artifact", "metadata", "archive", "spoiler-review"],
  },
  {
    id: "task-storyboard-sheet-candidate",
    laneId: "archive-candidate",
    title: "Decide whether Opening Movement Storyboard Sheet can become behind-the-scenes material",
    type: "Development vault review",
    storyArea: "Issue 01 / Development Vault",
    owner: "Art lead",
    collaborator: "Archive editor",
    priority: "low",
    dueLabel: "Later",
    statusLabel: "Candidate",
    decisionState: "not-final",
    summary:
      "The storyboard sheet is useful for collaborator review now. It may become a public behind-the-scenes artifact later, but only after spoilers and process notes are checked.",
    nextStep: "Mark internal-only for now and add a review reminder after Issue One preview feedback.",
    aiAssist:
      "Create a safe public label and identify any panels that should remain hidden until after release.",
    linkedItems: ["artifact_vault_storyboard_sheet", "issue_001"],
    tags: ["storyboard", "vault", "public-candidate", "not-final"],
  },
];

export const studioFocus = [
  {
    label: "Best next move",
    value: "Unblock Underpass Chorus frames so Glen can write final dialogue.",
  },
  {
    label: "Most useful gap",
    value: "Mara's voice rule can be filled now without waiting on art.",
  },
  {
    label: "Review risk",
    value: "Rain Signal beat change could expose the mythology too early.",
  },
  {
    label: "Archive watch",
    value: "Gold Ink Cassette is promising, but needs spoiler and rights labels first.",
  },
];

export function getTasksForLane(laneId: StudioLaneId) {
  return studioTasks.filter((task) => task.laneId === laneId);
}
