import { IssuePanel } from "@/components/studio/issue-panel";
import { StudioWorkflowBoard } from "@/components/studio/studio-workflow-board";
import { EmptyState } from "@/components/ui/empty-state";
import { MetadataLine } from "@/components/ui/metadata-line";
import { SignalFrame } from "@/components/ui/signal-frame";
import { getStudioOverview } from "@/lib/content/queries";

type StudioOverviewData = ReturnType<typeof getStudioOverview>;

interface StudioOverviewProps {
  data: StudioOverviewData;
}

export function StudioOverview({ data }: StudioOverviewProps) {
  return (
    <div className="space-y-6">
      <StudioWorkflowBoard
        projectTitle={data.project.title}
        issueTitle={data.issue.title}
        sceneCount={data.scenes.length}
        artifactCount={data.artifacts.length}
        loreCount={data.loreEntries.length}
      />

      <SignalFrame className="p-6 md:p-8">
        <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <MetadataLine label="Reference stack" value={data.release.title} />
            <h2 className="mt-4 font-display text-4xl leading-tight text-paper md:text-5xl">
              Keep the existing story material visible underneath the work board.
            </h2>
            <p className="mt-4 max-w-3xl text-base leading-7 text-paper/66">
              The board should not replace the archive. It should sit on top of scenes, artifacts, lore, tracks, and cue data so a collaborator can move from task to source without losing context.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-2">
            <InventoryTile label="Scenes" value={data.scenes.length} />
            <InventoryTile label="Artifacts" value={data.artifacts.length} />
            <InventoryTile label="Lore" value={data.loreEntries.length} />
            <InventoryTile label="Tracks" value={data.tracks.length} />
            <InventoryTile label="Cues" value={data.soundtrackCues.length} />
            <InventoryTile label="Media" value={data.mediaAssets.length} />
          </div>
        </div>
      </SignalFrame>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <IssuePanel issue={data.issue} scenes={data.scenes} />
        <div className="space-y-4 rounded-[6px] border border-paper/12 bg-ink/45 p-6">
          <MetadataLine label="Archive pulse" value="connected story material" />
          {data.artifacts.length > 0 ? (
            data.artifacts.slice(0, 4).map((artifact) => (
              <div key={artifact.id} className="border-b border-paper/10 pb-4 last:border-b-0 last:pb-0">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <p className="font-display text-xl text-paper">{artifact.title}</p>
                  <span className="rounded-full border border-paper/12 px-2.5 py-1 text-[0.62rem] uppercase tracking-[0.16em] text-paper/42">
                    {artifact.visibility}
                  </span>
                </div>
                <p className="mt-2 text-sm leading-6 text-paper/62">{artifact.publicDescription}</p>
              </div>
            ))
          ) : (
            <EmptyState
              title="No artifacts have surfaced."
              detail="Recovered objects will gather here once the issue begins to transmit evidence."
            />
          )}
        </div>
      </div>
    </div>
  );
}

function InventoryTile({ label, value }: { label: string; value: number }) {
  return (
    <div className="border border-paper/12 bg-ink/42 p-4">
      <p className="font-display text-3xl text-ember">{value}</p>
      <p className="mt-1 text-xs uppercase tracking-[0.2em] text-paper/50">{label}</p>
    </div>
  );
}
