import {
  getTasksForLane,
  studioFocus,
  studioLanes,
  studioTasks,
  type StudioPriority,
  type StudioTask,
} from "@/lib/studio/workflow";

interface StudioWorkflowBoardProps {
  projectTitle: string;
  issueTitle: string;
  sceneCount: number;
  artifactCount: number;
  loreCount: number;
}

const priorityStyles: Record<StudioPriority, string> = {
  high: "border-blood/60 bg-blood/15 text-red-100",
  medium: "border-ember/50 bg-ember/12 text-ember",
  low: "border-paper/18 bg-paper/5 text-paper/58",
};

const laneAccents = {
  gaps: "from-ember/18 to-transparent",
  "needs-input": "from-blood/20 to-transparent",
  drafting: "from-signal/16 to-transparent",
  review: "from-violet-400/12 to-transparent",
  "archive-candidate": "from-paper/12 to-transparent",
};

function priorityLabel(priority: StudioPriority) {
  return priority.charAt(0).toUpperCase() + priority.slice(1);
}

function countPriority(priority: StudioPriority) {
  return studioTasks.filter((task) => task.priority === priority).length;
}

function TaskCard({ task }: { task: StudioTask }) {
  return (
    <article className="group rounded-[10px] border border-paper/12 bg-ink/62 p-4 transition hover:border-signal/42 hover:bg-storm/60 hover:shadow-signal">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[0.62rem] uppercase tracking-[0.22em] text-signal/62">{task.type}</p>
          <h3 className="mt-2 font-display text-xl leading-6 text-paper">{task.title}</h3>
        </div>
        <span className={`shrink-0 rounded-full border px-2.5 py-1 text-[0.62rem] uppercase tracking-[0.18em] ${priorityStyles[task.priority]}`}>
          {priorityLabel(task.priority)}
        </span>
      </div>

      <p className="mt-3 text-sm leading-6 text-paper/66">{task.summary}</p>

      <dl className="mt-4 grid grid-cols-2 gap-2 text-xs">
        <div className="rounded-[6px] border border-paper/10 bg-paper/5 p-3">
          <dt className="uppercase tracking-[0.18em] text-paper/34">Owner</dt>
          <dd className="mt-1 text-paper/78">{task.owner}</dd>
        </div>
        <div className="rounded-[6px] border border-paper/10 bg-paper/5 p-3">
          <dt className="uppercase tracking-[0.18em] text-paper/34">Due</dt>
          <dd className="mt-1 text-paper/78">{task.dueLabel}</dd>
        </div>
      </dl>

      {task.blocker ? (
        <div className="mt-3 rounded-[6px] border border-blood/30 bg-blood/10 p-3 text-xs leading-5 text-red-100/82">
          <span className="uppercase tracking-[0.18em] text-red-100/50">Blocker</span>
          <p className="mt-1">{task.blocker}</p>
        </div>
      ) : null}

      <div className="mt-3 rounded-[6px] border border-signal/24 bg-signal/8 p-3 text-xs leading-5 text-paper/72">
        <span className="uppercase tracking-[0.18em] text-signal/62">Next step</span>
        <p className="mt-1">{task.nextStep}</p>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {task.tags.map((tag) => (
          <span key={tag} className="rounded-full border border-paper/10 px-2.5 py-1 text-[0.65rem] uppercase tracking-[0.14em] text-paper/42">
            {tag}
          </span>
        ))}
      </div>
    </article>
  );
}

export function StudioWorkflowBoard({
  projectTitle,
  issueTitle,
  sceneCount,
  artifactCount,
  loreCount,
}: StudioWorkflowBoardProps) {
  const blockedTasks = studioTasks.filter((task) => task.blocker).length;
  const glenTasks = studioTasks.filter((task) => task.owner === "Glen" || task.collaborator === "Glen").length;

  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-[14px] border border-paper/12 bg-ink/72 shadow-signal">
        <div className="border-b border-paper/10 bg-gradient-to-r from-blood/18 via-ink/70 to-signal/10 px-6 py-3 text-xs uppercase tracking-[0.24em] text-paper/62">
          Review prototype / not a final product decision
        </div>
        <div className="grid gap-8 p-6 lg:grid-cols-[1.15fr_0.85fr] lg:p-8">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-signal/72">Socarengue Studio / Writer workflow</p>
            <h1 className="mt-4 font-display text-5xl leading-tight text-paper md:text-7xl">Make the next creative move obvious.</h1>
            <p className="mt-5 max-w-3xl text-lg leading-8 text-paper/70">
              A collaborator-facing Studio view where Glen can see story bible gaps, blocked dialogue, approval requests, and archive candidates without digging through files.
            </p>
            <div className="mt-7 grid gap-3 sm:grid-cols-4">
              <Metric label="Glen focus" value={String(glenTasks)} detail="related cards" />
              <Metric label="Blocked" value={String(blockedTasks)} detail="needs input" />
              <Metric label="High priority" value={String(countPriority("high"))} detail="move first" />
              <Metric label="Archive" value="2" detail="candidates" />
            </div>
          </div>
          <aside className="rounded-[10px] border border-paper/12 bg-paper/5 p-5">
            <p className="text-xs uppercase tracking-[0.26em] text-ember/72">Glen logs in</p>
            <h2 className="mt-3 font-display text-3xl text-paper">Writer view</h2>
            <p className="mt-3 text-sm leading-6 text-paper/62">
              Current context: {projectTitle}, {issueTitle}. The system should show what Glen can draft now, what is blocked by frames, and what needs review before it becomes canon.
            </p>
            <div className="mt-5 space-y-3">
              {studioFocus.map((item) => (
                <div key={item.label} className="border-l border-signal/34 pl-4">
                  <p className="text-[0.62rem] uppercase tracking-[0.2em] text-signal/62">{item.label}</p>
                  <p className="mt-1 text-sm leading-6 text-paper/72">{item.value}</p>
                </div>
              ))}
            </div>
          </aside>
        </div>
      </section>

      <section className="grid gap-6 xl:grid-cols-[1fr_360px]">
        <div className="overflow-hidden rounded-[14px] border border-paper/12 bg-ink/56">
          <div className="flex flex-wrap items-end justify-between gap-4 border-b border-paper/10 p-5">
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-signal/62">Workflow board</p>
              <h2 className="mt-2 font-display text-3xl text-paper">Gap -> input -> draft -> review -> archive</h2>
            </div>
            <p className="max-w-xl text-sm leading-6 text-paper/50">
              The lanes are intentionally production-specific. They expose creative dependency, not just generic task status.
            </p>
          </div>

          <div className="grid gap-4 overflow-x-auto p-5 lg:grid-cols-5">
            {studioLanes.map((lane) => {
              const laneTasks = getTasksForLane(lane.id);

              return (
                <section key={lane.id} className="min-w-[280px] rounded-[12px] border border-paper/10 bg-paper/[0.035]">
                  <div className={`rounded-t-[12px] border-b border-paper/10 bg-gradient-to-b ${laneAccents[lane.id]} p-4`}>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-display text-2xl text-paper">{lane.title}</h3>
                        <p className="mt-2 text-xs leading-5 text-paper/46">{lane.description}</p>
                      </div>
                      <span className="rounded-full border border-paper/14 px-2.5 py-1 text-xs text-paper/56">{laneTasks.length}</span>
                    </div>
                  </div>
                  <div className="space-y-3 p-3">
                    {laneTasks.map((task) => (
                      <TaskCard key={task.id} task={task} />
                    ))}
                  </div>
                </section>
              );
            })}
          </div>
        </div>

        <aside className="space-y-6">
          <section className="rounded-[14px] border border-signal/22 bg-signal/8 p-5 shadow-signal">
            <p className="text-xs uppercase tracking-[0.26em] text-signal/72">Socarengue Copilot</p>
            <h2 className="mt-3 font-display text-3xl text-paper">Suggested next action</h2>
            <p className="mt-3 text-sm leading-6 text-paper/70">
              Glen should not start final Underpass dialogue yet. Ask storyboard for frame timing, then draft the call-and-response once the reveal is sequenced.
            </p>
            <div className="mt-5 space-y-3 text-sm leading-6 text-paper/64">
              <AiAction title="Request detail" body="Ask art whether frames 08-12 are one continuous reveal or three beats." />
              <AiAction title="Open source" body="Link directly to Underpass Chorus, Torn Underpass Poster, and the soundtrack cue." />
              <AiAction title="Safe draft" body="Let Glen draft placeholder rhythm lines marked non-canon until frames land." />
            </div>
          </section>

          <section className="rounded-[14px] border border-paper/12 bg-ink/56 p-5">
            <p className="text-xs uppercase tracking-[0.26em] text-ember/72">Artifact upload labels</p>
            <h2 className="mt-3 font-display text-3xl text-paper">Public archive readiness</h2>
            <div className="mt-5 grid gap-2 text-sm">
              <LabelRow label="Visibility" value="Internal / Candidate / Public" />
              <LabelRow label="Canon" value="Draft / Canon / Reference only" />
              <LabelRow label="Rights" value="Owned / Needs review / Reference" />
              <LabelRow label="Spoiler" value="None / Mild / Major" />
              <LabelRow label="Linked to" value="Scene, lore, track, issue" />
            </div>
          </section>

          <section className="rounded-[14px] border border-paper/12 bg-ink/56 p-5">
            <p className="text-xs uppercase tracking-[0.26em] text-paper/42">Signal inventory</p>
            <dl className="mt-4 grid grid-cols-3 gap-2 text-center">
              <MiniInventory label="Scenes" value={sceneCount} />
              <MiniInventory label="Artifacts" value={artifactCount} />
              <MiniInventory label="Lore" value={loreCount} />
            </dl>
          </section>
        </aside>
      </section>
    </div>
  );
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-[8px] border border-paper/12 bg-paper/5 p-4">
      <p className="font-display text-3xl text-ember">{value}</p>
      <p className="mt-1 text-[0.62rem] uppercase tracking-[0.2em] text-paper/42">{label}</p>
      <p className="mt-2 text-xs text-paper/46">{detail}</p>
    </div>
  );
}

function AiAction({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-[8px] border border-signal/18 bg-ink/48 p-3">
      <p className="text-xs uppercase tracking-[0.2em] text-signal/60">{title}</p>
      <p className="mt-1">{body}</p>
    </div>
  );
}

function LabelRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-paper/10 py-2 last:border-b-0">
      <span className="text-paper/42">{label}</span>
      <span className="text-right text-paper/72">{value}</span>
    </div>
  );
}

function MiniInventory({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-[8px] border border-paper/10 bg-paper/5 p-3">
      <dt className="font-display text-2xl text-paper">{value}</dt>
      <dd className="mt-1 text-[0.6rem] uppercase tracking-[0.18em] text-paper/38">{label}</dd>
    </div>
  );
}
